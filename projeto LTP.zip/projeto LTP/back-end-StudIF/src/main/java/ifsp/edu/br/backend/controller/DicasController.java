package ifsp.edu.br.backend.controller;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ifsp.edu.br.demo.model.Perfil;
import ifsp.edu.br.demo.repository.PerfilRepository;


@RestController
@CrossOrigin
public class DicasController {
    @GetMapping("/dicas")
    public List<Dicas> listaTodosDicas() {
        return DicasRepository.all();
    }

    @GetMapping("/dicas/{id}")
    public Perfil recuperarDicasById(@PathVariable("id") int idDicas) {
        return DicasRepository.getById(idDicas);
    }

    @PostMapping("/dicas")
    public void addDicas(
            @RequestBody Dicas dicas) {
        DicasRepository.add(dicas);
    }
    
    @DeleteMapping("/dicas/{id}")
    public boolean deletaDicas(@PathVariable("id") int id) {
        boolean deletar = DicasRepository.deletaDicasbyId(id - 1);
        if (!deletar) {
            return false;
        }
        return true;
    }
}
